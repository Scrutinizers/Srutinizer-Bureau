﻿$(document).ready(function () {
    $("#btn_signin").click(function () {
        var name = $("#publicname").val();
        var password = $("#publicpassword").val();
       

         //alert(name+" "+password)
        $.ajax({
            url: '/Home/Signin',
            async: false,
            type: 'GET',
            data: { "name": name, "password": password},
            dataType: 'json',
            contentType: 'application/json;charset=utf-8',
            success: function (data) {               
                if (data > 0)
                    window.location.href = "/Home/UserRegistration";
                else
                    $("#lblerror").text("Invalid UserName or Password");
            },
            error: function (request, error) {
                alert("Request: " + JSON.stringify(request));

            }

        });


    });

});
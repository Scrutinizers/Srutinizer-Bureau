﻿$(document).ready(function () {
    $("#btnregister").click(function () {
        var name = $("#uname").val();
        var password = $("#upassword").val();
        var city = $("#ucity").val();
        var address = $("#uaddress").val();
        var complainttype = $("#ucomplaintype").val();
        var complaint = $("#ucomplaint").val();

        // alert(name+" "+password+" "+city+" "+address+" "+complainttype+" "+complaint)
        $.ajax({
            url: '/Home/Registration',
            async: false,
            type: 'GET',
            data: { "name": name,"password":password,"city":city,"address":address,"complainttype":complainttype,"complaint":complaint },
            dataType: 'json',
            contentType: 'application/json;charset=utf-8',
            success: function (data) {
                alert("Registration Done");
            },
            error: function (request, error) {
                alert("Request: " + JSON.stringify(request));

            }

        });


    });

});
﻿$(document).ready(function () {
    $("#btn_appoint").click(function () {
        var name = $("#oname").val();
        var password = $("#opassword").val();
        var stationno = $("#ostationno").val();
        var stationaddress = $("#ostationaddress").val();
        var designation = $("#odesignation").val();
        var gender = $("#ogender").val();
        var age = $("#oage").val();

        alert(name + " " + password + " " + stationno + " " + stationaddress + " " + designation + " " + gender + " " + age)
        //$.ajax({
        //    url: '/Home/Registration',
        //    async: false,
        //    type: 'GET',
        //    data: { "name": name, "password": password, "city": city, "address": address, "complainttype": complainttype, "complaint": complaint },
        //    dataType: 'json',
        //    contentType: 'application/json;charset=utf-8',
        //    success: function (data) {
        //        alert("Registration Done");
        //    },
        //    error: function (request, error) {
        //        alert("Request: " + JSON.stringify(request));

        //    }

        //});


    });

});
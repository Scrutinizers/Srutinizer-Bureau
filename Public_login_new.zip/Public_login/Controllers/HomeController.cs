﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Public_login.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult SignUp()
        {
            return View();
        }
        public ActionResult UserRegistration()
        {
            return View();
        }
        public ActionResult AppointingOfficer()
        {
            return View();
        }
        
        public int Registration(string name,string password,string city,string address,string complainttype,string complaint)
        {
            SqlConnection con = new SqlConnection("Data Source=DS-4121AA216893\\SQLEXPRESS;Initial Catalog=Test_Project;User Id=sa;Password=Welcome@123;");
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into UserDetails(userName,userPassword,city,address,complaintType,complaint)values(@name,@password,@city,@address,@complainttype,@complaint)", con);
            cmd.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@password", password);
            cmd.Parameters.AddWithValue("@city", city);
            cmd.Parameters.AddWithValue("@address", address);
            cmd.Parameters.AddWithValue("@complainttype", complainttype);
            cmd.Parameters.AddWithValue("@complaint", complaint);
            int result = cmd.ExecuteNonQuery();
            return result;
        }
        public int Signin(string name,string password)
        {
            SqlConnection con = new SqlConnection("Data Source=DS-4121AA216893\\SQLEXPRESS;Initial Catalog=Test_Project;User Id=sa;Password=Welcome@123;");
            con.Open();
            SqlCommand cmd = new SqlCommand("[USP_checkpublicuser]", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@userName", name);
            cmd.Parameters.AddWithValue("@password", password);
            int result = (int)cmd.ExecuteScalar();
            return result;
        }
    }
}

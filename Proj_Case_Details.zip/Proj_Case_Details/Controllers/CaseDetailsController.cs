﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Proj_Case_Details.Controllers
{
    public class CaseDetailsController : Controller
    {
        //
        // GET: /CaseDetails/
        string cs = "Data Source=DS-A101AA298116\\SQLEXPRESS;Initial Catalog=Project_Testing;User ID=sa;Password=Welcome@123;";
        public ActionResult Index()
        {
            return View();
        }
        public int Case_Details_Insert(string name, string date, string witness, string evidence, string description)
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into CaseDetails(caseName,date,evidence,witness,caseDescription) values(@name,@date,@evidence,@witness,@description)", con);
            cmd.Parameters.AddWithValue("@name", name);
            cmd.Parameters.AddWithValue("@date", date);
            cmd.Parameters.AddWithValue("@evidence", evidence);
            cmd.Parameters.AddWithValue("@witness", witness);
            cmd.Parameters.AddWithValue("@description", description);
            int result = cmd.ExecuteNonQuery();
            return result;
        }

    }
}

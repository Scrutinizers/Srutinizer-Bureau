﻿$(document).ready(function () {
    $("#submit").click(function () {
        var Name = $("#name").val();
        var Date = $("#date").val();
        var Evidence = $("#evidence").val();
        var Witness = $("#witness").val();
        var Description = $("#description").val();

        //alert(Name + " " + Date + " " + Evidence + " " + Witness + " " + Description + " ");

        $.ajax({
            url: '/CaseDetails/Case_Details_Insert',
            async: false,
            type: 'GET',
            data: {"name" : Name,"date" : Date,"witness" : Witness,"evidence" : Evidence,"description" : Description},
            dataType: 'json',
            ContentType: 'application/json;charset=utf-8',
            Success: function (data) {
                alert("Registered successfully");
            },

            error: function (request, error) {
                alert("Request:" + JSON.stringify(request));
            }
        });
    });

});
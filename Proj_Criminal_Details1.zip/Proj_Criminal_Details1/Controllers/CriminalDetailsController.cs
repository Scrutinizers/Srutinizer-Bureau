﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Proj_Criminal_Details1.Controllers
{
    public class CriminalDetailsController : Controller
    {
        //
        // GET: /CriminalDetails/
        string cs = "Data Source=DS-A101AA298116\\SQLEXPRESS;Initial Catalog=Project_Testing;User ID=sa;Password=Welcome@123;";
        public ActionResult Index()
        {
            return View();
        }
        public int Criminal_View(string criminalName,string birthdate,string gender,int height,int weight,string identity,string native,string address)
        {
            SqlConnection con = new SqlConnection(cs);
            con.Open();
            SqlCommand cmd = new SqlCommand("insert into CriminalDetails(criminalName,gender,height,weight,identification,native,address) values(@criminal_nm,@gender,@height,@weight,@identify,@native,@address)", con);
            cmd.Parameters.AddWithValue("@criminal_nm", criminalName);
            cmd.Parameters.AddWithValue("@gender", birthdate);
            cmd.Parameters.AddWithValue("@height", height);
            cmd.Parameters.AddWithValue("@weight", weight);
            cmd.Parameters.AddWithValue("@identify", identity);
            cmd.Parameters.AddWithValue("@native", native);
            cmd.Parameters.AddWithValue("@address", address);
            int result = cmd.ExecuteNonQuery();
            return result;
        }

    }
}

﻿using System.Web;
using System.Web.Mvc;

namespace Proj_Criminal_Details1
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
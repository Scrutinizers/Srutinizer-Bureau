﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Proj_Officer_Login.Controllers
{
    public class Officer_loginController : Controller
    {
        //
        // GET: /Officer_login/

        public ActionResult Index()
        {
            return View();
        }

    }
}

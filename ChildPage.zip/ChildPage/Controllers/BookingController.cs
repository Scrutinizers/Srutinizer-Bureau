﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ChildPage.Controllers
{
    public class BookingController : Controller
    {
        //
        // GET: /Booking/

        public ActionResult Booking()
        {
            return View();
        }
        public ActionResult Arrest()
        {
            return View();
        }


    }
}

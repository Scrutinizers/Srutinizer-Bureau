﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Public_login.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult SignUp()
        {
            return View();
        }
        public ActionResult UserRegistration()
        {
            return View();
        }
        public ActionResult AppointingOfficer()
        {
            return View();
        }
    }
}
